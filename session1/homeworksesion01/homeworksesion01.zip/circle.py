from turtle import *

shape('triangle')
color('blue')
speed(-1)

fillcolor('yellow')
begin_fill()
circle(50)

end_fill()
mainloop()
