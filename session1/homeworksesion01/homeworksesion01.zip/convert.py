c = int(input('nhap do C:'))
f = c*1.8+32
print (c,'(c)','=',f,'(f)')
