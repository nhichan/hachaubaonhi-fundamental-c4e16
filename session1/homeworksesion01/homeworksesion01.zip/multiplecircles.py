from turtle import *

shape('triangle')
color('green')
speed(-1)

for i in range (6):
    circle(100)
    left(60)

mainloop()
