from math import pi

r = int(input('nhap ban kinh hinh tron: '))
area = pi*(r**2)
print ('area = ',area)
